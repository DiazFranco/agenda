package agenda;

public class Principal {

    public static void main(String args[]) {        
        Controlador c = new Controlador();
        c.iniciar();
    }
}



//Agregar exportacion a txt o xslx

//Agregar buscador