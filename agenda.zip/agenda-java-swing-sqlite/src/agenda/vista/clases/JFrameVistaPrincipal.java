
package agenda.vista.clases;

import agenda.modelo.clases.Contacto;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.MouseListener;
import java.util.Collection;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class JFrameVistaPrincipal extends JFrameTemplate {

    public JFrameVistaPrincipal(String titulo, Component parent) {
        super(titulo, parent);
        initComponents();
        cargarIconos();
        ocultarColumnaID();
        actualizarEstado(false);
    }

    public JFrameVistaPrincipal(String titulo) {
        this(titulo, null);
    }

    private void cargarIconos() {
        cargarIcono(jButtonConectar, "broken-link.png");
        cargarIcono(jButtonVaciar, "trash-icon.png");
        cargarIcono(jButtonAgregar, "add-user-icon.png");
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jPanelCabecera = new JPanel();
        jPanelFiltro = new JPanel();
        jLabelLeyenda = new JLabel();
        jLabelEstado = new JLabel();
        jPanelBotonera = new JPanel();
        jButtonConectar = new JButton();
        jButtonVaciar = new JButton();
        jButtonAgregar = new JButton();
        jScrollPane1 = new JScrollPane();
        jTable1 = new JTable();

        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setBackground(new Color(152, 118, 116));
        setResizable(false);
        getContentPane().setLayout(new BorderLayout(10, 10));

        jPanelCabecera.setPreferredSize(new Dimension(850, 80));
        jPanelCabecera.setLayout(new BorderLayout());

        jPanelFiltro.setPreferredSize(new Dimension(400, 50));
        jPanelFiltro.setLayout(new FlowLayout(java.awt.FlowLayout.CENTER, 5, 10));


        jPanelCabecera.add(jPanelFiltro, BorderLayout.WEST);

        jLabelEstado.setFont(new Font("Lato Black", 1, 18)); // NOI18N
        jLabelEstado.setHorizontalAlignment(SwingConstants.CENTER);
        jLabelEstado.setText("status");
        jPanelCabecera.add(jLabelEstado, BorderLayout.CENTER);

        jPanelBotonera.setPreferredSize(new Dimension(265, 40));
        jPanelBotonera.setLayout(new FlowLayout(java.awt.FlowLayout.CENTER, 5, 18));

        jButtonConectar.setBackground(new Color(238, 245, 247));
        jButtonConectar.setFont(new Font("Tahoma", 0, 18)); // NOI18N
        jButtonConectar.setForeground(new Color(255, 250, 240));
        jButtonConectar.setHorizontalTextPosition(SwingConstants.RIGHT);
        jButtonConectar.setIconTextGap(20);
        jButtonConectar.setMaximumSize(new Dimension(60, 40));
        jButtonConectar.setMinimumSize(new Dimension(40, 40));
        jButtonConectar.setPreferredSize(new Dimension(60, 40));
        jPanelBotonera.add(jButtonConectar);

        jButtonVaciar.setBackground(new Color(238, 245, 247));
        jButtonVaciar.setFont(new Font("Tahoma", 0, 18)); // NOI18N
        jButtonVaciar.setForeground(new Color(255, 250, 240));
        jButtonVaciar.setEnabled(false);
        jButtonVaciar.setHorizontalTextPosition(SwingConstants.RIGHT);
        jButtonVaciar.setIconTextGap(20);
        jButtonVaciar.setToolTipText("Vaciar contactos");
        jButtonVaciar.setMaximumSize(new Dimension(60, 40));
        jButtonVaciar.setMinimumSize(new Dimension(40, 40));
        jButtonVaciar.setPreferredSize(new Dimension(60, 40));
        jPanelBotonera.add(jButtonVaciar);

        jButtonAgregar.setBackground(new Color(238, 245, 247));
        jButtonAgregar.setFont(new Font("Tahoma", 0, 18)); // NOI18N
        jButtonAgregar.setForeground(new Color(255, 250, 240));
        jButtonAgregar.setEnabled(false);
        jButtonAgregar.setHorizontalTextPosition(SwingConstants.RIGHT);
        jButtonAgregar.setIconTextGap(20);
        jButtonAgregar.setToolTipText("Agregar contacto");
        jButtonAgregar.setMaximumSize(new Dimension(60, 40));
        jButtonAgregar.setMinimumSize(new Dimension(40, 40));
        jButtonAgregar.setPreferredSize(new Dimension(60, 40));
        jPanelBotonera.add(jButtonAgregar);

        jPanelCabecera.add(jPanelBotonera, BorderLayout.EAST);

        getContentPane().add(jPanelCabecera, BorderLayout.NORTH);

        jTable1.setBackground(new Color(250, 249, 245));
        jTable1.setFont(new Font("Lato", 0, 18)); // NOI18N
        jTable1.setModel(new DefaultTableModel(
                new Object[][]{

                },
                new String[]{
                        "ID", "Nombre", "Apellido", "Teléfono"
                }
        ) {
            Class[] types = new Class[]{
                    java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean[]{
                    false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types[columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit[columnIndex];
            }
        });
        jTable1.setDragEnabled(true);
        jTable1.setGridColor(new Color(36, 123, 160));
        jTable1.setIntercellSpacing(new Dimension(0, 3));
        jTable1.setRowHeight(30);
        jTable1.setSelectionBackground(new Color(75, 147, 177));
        jTable1.setSelectionForeground(new Color(238, 245, 247));
        jTable1.setShowVerticalLines(false);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(0);
        }

        getContentPane().add(jScrollPane1, BorderLayout.CENTER);

        pack();
        setLocationRelativeTo(null);
    }

    public boolean confirmar(String mensaje) {
        int res = JOptionPane.showConfirmDialog(null, mensaje, "Confirmar...", JOptionPane.YES_NO_OPTION);
        return res == 0;
    }

    public void listarContactos(Collection<Contacto> contactos) {
        limpiarFilas();
        for (Contacto c : contactos) {
            agregarFila(c.getId(), c.getNombre(), c.getApellido(), c.getTelefono());
        }
    }

    private void agregarFila(int id, String nombre, String apellido, String telefono) {
        DefaultTableModel dtf = (DefaultTableModel) this.jTable1.getModel();
        dtf.addRow(new Object[]{id, nombre, apellido, telefono});
    }

    private void limpiarFilas() {
        DefaultTableModel dtf = (DefaultTableModel) this.jTable1.getModel();
        while (dtf.getRowCount() > 0) {
            dtf.removeRow(0);
        }
    }


    private void ocultarColumnaID() {
        this.jTable1.getTableHeader().getColumnModel().getColumn(0).setMaxWidth(0);
        this.jTable1.getTableHeader().getColumnModel().getColumn(0).setMinWidth(0);
        this.jTable1.getColumnModel().getColumn(0).setMaxWidth(0);
        this.jTable1.getColumnModel().getColumn(0).setMinWidth(0);
    }

    public int obtenerIDSeleccionado() {
        int nroFila = this.jTable1.getSelectedRow();
        return (int) this.jTable1.getValueAt(nroFila, 0);
    }

    public final void actualizarEstado(boolean estaConectado) {
        this.jLabelLeyenda.setVisible(estaConectado);
        activarControles(estaConectado);
        this.jButtonConectar.setEnabled(!estaConectado);
        if (estaConectado) {
            this.jLabelEstado.setText("CONECTADO");
            this.jLabelEstado.setForeground(new Color(55, 184, 88));
        } else {
            this.jLabelEstado.setText("NO CONECTADO");
            this.jLabelEstado.setForeground(new Color(255, 87, 71));
        }
    }

    private void activarControles(boolean flag) {
        for (int i = 1; i < this.jPanelBotonera.getComponents().length; i++) {
            this.jPanelBotonera.getComponent(i).setEnabled(flag);
        }
    }

    public void manejarAccionConectar(ActionListener al) {
        this.jButtonConectar.addActionListener(al);
    }

    public void manejarAccionAgregar(ActionListener al) {
        this.jButtonAgregar.addActionListener(al);
    }

    public void manejarAccionVaciar(ActionListener al) {
        this.jButtonVaciar.addActionListener(al);
    }

    public void manejarClickEnTabla(MouseListener ml) {
        this.jTable1.addMouseListener(ml);
    }

    private JButton jButtonAgregar;
    private JButton jButtonConectar;
    private JButton jButtonVaciar;
    private JLabel jLabelEstado;
    private JLabel jLabelLeyenda;
    private JPanel jPanelBotonera;
    private JPanel jPanelCabecera;
    private JPanel jPanelFiltro;
    private JScrollPane jScrollPane1;
    private JTable jTable1;
}
