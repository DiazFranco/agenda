package agenda.vista.clases;

import agenda.modelo.clases.Contacto;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Locale;
import javax.swing.*;

import org.jdesktop.swingx.JXDatePicker;

public abstract class JFrameVistaFormulario extends JFrameTemplate {

    public static final Locale LOCALE_AR = new Locale("es", "AR");

    public JFrameVistaFormulario(String titulo, Component parent) {
        super(titulo, parent);
        initComponents();
        cargarIconos();
        manejarAccionCerrar();
    }

    public JFrameVistaFormulario(String titulo) {
        this(titulo, null);
    }
    
    private void cargarIconos() {
        cargarIcono(jButtonCerrar, "close-icon.png");
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {

        jPanelContenido = new JPanel();
        jPanelBotonera = new JPanel();
        jButtonCerrar = new JButton();
        jPanelEdicion = new JPanel();
        jPanelIconos = new JPanel();
        jLabelCredencial = new JLabel();
        jLabelMail = new JLabel();
        jLabelTelefono = new JLabel();
        jPanelCampos = new JPanel();
        jPanelNombreApellido = new JPanel();
        jTextFieldNombre = new JTextField();
        jTextFieldApellido = new JTextField();
        jTextFieldMail = new JTextField();
        jTextFieldTelefono = new JTextField();

        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);

        jPanelBotonera.setLayout(new GridLayout(3, 1, 0, 10));

        jButtonCerrar.setBackground(new Color(238, 245, 247));
        jButtonCerrar.setFont(new Font("Lato", 0, 16)); // NOI18N
        jButtonCerrar.setForeground(new Color(24, 19, 9));
        jButtonCerrar.setIcon(new ImageIcon(getClass().getResource("/agenda/vista/recursos/close-icon.png"))); // NOI18N
        jButtonCerrar.setText("Cerrar");
        jButtonCerrar.setHorizontalAlignment(SwingConstants.CENTER);
        jButtonCerrar.setHorizontalTextPosition(SwingConstants.RIGHT);
        jButtonCerrar.setIconTextGap(20);
        jButtonCerrar.setPreferredSize(new Dimension(400, 53));
        jPanelBotonera.add(jButtonCerrar);

        jPanelEdicion.setPreferredSize(new Dimension(100, 800));
        jPanelEdicion.setLayout(new BoxLayout(jPanelEdicion, javax.swing.BoxLayout.LINE_AXIS));



        jPanelIconos.setMinimumSize(new Dimension(70, 192));
        jPanelIconos.setPreferredSize(new Dimension(0, 800));
        jPanelIconos.setLayout(new GridLayout(6, 1));

        jLabelCredencial.setFont(new Font("Lato", 0, 15)); // NOI18N
        jLabelCredencial.setHorizontalAlignment(SwingConstants.CENTER);
        jLabelCredencial.setText("Nombre:");
        jPanelIconos.add(jLabelCredencial);

        jLabelMail.setFont(new Font("Lato", 0, 15)); // NOI18N
        jLabelMail.setHorizontalAlignment(SwingConstants.CENTER);
        jLabelMail.setText("Mail:");
        jPanelIconos.add(jLabelMail);

        jLabelTelefono.setFont(new java.awt.Font("Lato", 0, 15)); // NOI18N
        jLabelTelefono.setHorizontalAlignment(SwingConstants.CENTER);
        jLabelTelefono.setText("Teléfono:");
        jPanelIconos.add(jLabelTelefono);

        jPanelEdicion.add(jPanelIconos);

        jPanelCampos.setLayout(new GridLayout(6, 1));

        jPanelNombreApellido.setLayout(new GridLayout(1, 2));

        jTextFieldNombre.setFont(new Font("Lato", 0, 20)); // NOI18N
        jTextFieldNombre.setForeground(new Color(24, 19, 9));
        jTextFieldNombre.setMargin(new Insets(5, 5, 5, 5));
        jTextFieldNombre.setName("Nombre"); // NOI18N
        jTextFieldNombre.setSelectionColor(new Color(255, 206, 91));
        jPanelNombreApellido.add(jTextFieldNombre);

        jTextFieldApellido.setFont(new Font("Lato", 0, 20)); // NOI18N
        jTextFieldApellido.setForeground(new Color(24, 19, 9));
        jTextFieldApellido.setMargin(new Insets(5, 5, 5, 5));
        jTextFieldApellido.setName("Apellido"); // NOI18N
        jTextFieldApellido.setSelectionColor(new Color(255, 206, 91));
        jPanelNombreApellido.add(jTextFieldApellido);

        jPanelCampos.add(jPanelNombreApellido);

        jTextFieldMail.setFont(new Font("Lato", 0, 20)); // NOI18N
        jTextFieldMail.setForeground(new Color(24, 19, 9));
        jTextFieldMail.setMargin(new Insets(5, 5, 5, 5));
        jTextFieldMail.setName("Mail"); // NOI18N
        jTextFieldMail.setSelectionColor(new Color(255, 206, 91));
        jPanelCampos.add(jTextFieldMail);

        jTextFieldTelefono.setFont(new Font("Lato", 0, 20)); // NOI18N
        jTextFieldTelefono.setForeground(new Color(24, 19, 9));
        jTextFieldTelefono.setMargin(new Insets(5, 5, 5, 5));
        jTextFieldTelefono.setName("Teléfono"); // NOI18N
        jTextFieldTelefono.setSelectionColor(new Color(255, 206, 91));
        jPanelCampos.add(jTextFieldTelefono);


        jPanelEdicion.add(jPanelCampos);

        GroupLayout jPanelContenidoLayout = new GroupLayout(jPanelContenido);
        jPanelContenido.setLayout(jPanelContenidoLayout);
        jPanelContenidoLayout.setHorizontalGroup(
            jPanelContenidoLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(jPanelContenidoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelContenidoLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(jPanelBotonera, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE))
                .addContainerGap(394, Short.MAX_VALUE))
            .addGroup(jPanelContenidoLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(GroupLayout.Alignment.TRAILING, jPanelContenidoLayout.createSequentialGroup()
                    .addContainerGap(158, Short.MAX_VALUE)
                    .addComponent(jPanelEdicion, GroupLayout.PREFERRED_SIZE, 380, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );
        jPanelContenidoLayout.setVerticalGroup(
            jPanelContenidoLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
            .addGroup(GroupLayout.Alignment.LEADING, jPanelContenidoLayout.createSequentialGroup()
                .addContainerGap()
                    .addComponent(jPanelBotonera, javax.swing.GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap())
            .addGroup(jPanelContenidoLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addGroup(GroupLayout.Alignment.TRAILING, jPanelContenidoLayout.createSequentialGroup()
                    .addComponent(jPanelEdicion, GroupLayout.PREFERRED_SIZE, 300, GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        getContentPane().add(jPanelContenido, java.awt.BorderLayout.CENTER);

        pack();
    }


    public Contacto getContacto() {
        validarDatos();
        String nom = this.jTextFieldNombre.getText();
        String ape = this.jTextFieldApellido.getText();
        String mail = this.jTextFieldMail.getText();
        String tel = this.jTextFieldTelefono.getText();
        return new Contacto(0, nom, ape, mail, tel);
    }

    private void validarDatos() {
        Component[] campos = this.jPanelCampos.getComponents();
        Component[] nomApe = ((JPanel) campos[0]).getComponents();
        for (int i = 0; i < this.jPanelNombreApellido.getComponents().length; i++) {
            JTextField tf = (JTextField) this.jPanelNombreApellido.getComponent(i);
            if (tf.getText().isEmpty()) {
                throw new IllegalStateException("El campo \"" + tf.getName() + "\" está vacío");
            }
        }
        for (int i = 1; i < this.jPanelCampos.getComponents().length-2; i++) {
            JTextField tf = (JTextField) campos[i];
            if (tf.getText().isEmpty()) {
                throw new IllegalStateException("El campo \"" + tf.getName() + "\" está vacío");
            }
        }
        if (!esNumeroEntero(this.jTextFieldTelefono.getText())) {
            throw new IllegalStateException("El valor del campo \"" + this.jTextFieldTelefono.getName() + "\" no representa un número de teléfono");
        }

    }
    
    public final void habilitarCampos (boolean flag) {
        for (int i = 0; i < this.jPanelNombreApellido.getComponents().length; i++) {
            JTextField campo = (JTextField) this.jPanelNombreApellido.getComponent(i);
            campo.setEditable(flag);
        }
        for (int i = 1; i < this.jPanelCampos.getComponents().length-2; i++) {
            JTextField campo = (JTextField) this.jPanelCampos.getComponent(i);
            campo.setEditable(flag);
        }
    }

    private boolean esNumeroEntero(String cad) {
        boolean esEntero = true;
        try {
            cad.trim();
            cad.replaceAll(" ", "");
            Integer.parseInt(cad);
        } catch (NumberFormatException e) {
            esEntero = false;
        }
        return esEntero;
    }


    protected JTextField getjTextFieldApellido() {
        return jTextFieldApellido;
    }

    protected JTextField getjTextFieldMail() {
        return jTextFieldMail;
    }

    protected JTextField getjTextFieldNombre() {
        return jTextFieldNombre;
    }

    protected JTextField getjTextFieldTelefono() {
        return jTextFieldTelefono;
    }


    protected JPanel getJPanelBotonera() {
        return jPanelBotonera;
    }

    private void manejarAccionCerrar() {
        this.jButtonCerrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        });
    }

    private JButton jButtonCerrar;
    private JLabel jLabelCredencial;
    private JLabel jLabelMail;
    private JLabel jLabelTelefono;
    private JPanel jPanelBotonera;
    private JPanel jPanelCampos;
    private JPanel jPanelContenido;
    private JPanel jPanelEdicion;
    private JPanel jPanelIconos;
    private JPanel jPanelNombreApellido;
    private JTextField jTextFieldApellido;
    private JTextField jTextFieldMail;
    private JTextField jTextFieldNombre;
    private javax.swing.JTextField jTextFieldTelefono;
}
