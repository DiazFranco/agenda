package agenda.modelo.clases;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

public class Modelo {

    private Connection conexion;

    public void conectarBD(String driver, String url, String user, String pass) {
        this.conexion = ConexionBD.getConexion(driver, url, user, pass);
    }

    public Collection<Contacto> obtenerContactos() {
        try ( Statement stmt = this.conexion.createStatement();) {
            Collection<Contacto> contactos = new ArrayList<>();
            String query = "SELECT * FROM CONTACTOS ";
            try ( ResultSet rs = stmt.executeQuery(query);) {
                while (rs.next()) {
                    contactos.add(generarContacto(rs));
                }
                return contactos;
            }
        } catch (Exception ex) {
            throw new RuntimeException("No se pudieron obtener los contactos", ex);
        }
    }

    public Contacto obtenerContacto(int id) {
        String query = "SELECT * FROM contactos WHERE id = " + id;
        try ( Statement stmt = this.conexion.createStatement();  ResultSet rs = stmt.executeQuery(query);) {
            rs.next();
            Contacto contacto = generarContacto(rs);
            return contacto;
        } catch (Exception ex) {
            throw new RuntimeException("No se pudo obtener contacto con ID " + id, ex);
        }
    }

    public void agregarContacto(Contacto co) throws SQLException {
        String query = "INSERT INTO contactos VALUES (null,?,?,?,?)";
        try ( PreparedStatement ps = this.conexion.prepareStatement(query);) {
            cargarDatosDeContactoEnSentencia(co, ps);
            ps.executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new RuntimeException("No se pudo agregar contacto\n" + co, ex);
        }
    }

    public void actualizarContacto(Contacto co) throws SQLException {
        String campos = "nombre = ?, apellido = ?, mail = ?, telefono = ?";
        String query = "UPDATE contactos SET " + campos + " WHERE id = " + co.getId();
        try ( PreparedStatement ps = this.conexion.prepareStatement(query);) {
            cargarDatosDeContactoEnSentencia(co, ps);
            ps.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException("No se pudo actualizar contacto\n" + co, ex);
        }
    }

    public void borrarContacto(int id) throws SQLException {
        try ( Statement s = conexion.createStatement();) {
            s.executeUpdate("DELETE FROM contactos WHERE contactos.id = " + id);
        } catch (Exception ex) {
            throw new RuntimeException("No se pudo borrar contacto con id " + id, ex);
        }
    }

    public void vaciarAgenda() throws SQLException {
        try ( Statement s = conexion.createStatement();) {
            s.executeUpdate("DELETE FROM contactos");
            s.executeUpdate("UPDATE SQLITE_SEQUENCE SET SEQ=0 WHERE NAME='contactos'"); // Reinicia el contador de IDs
        } catch (Exception ex) {
            throw new RuntimeException("No se pudo vaciar la agenda", ex);
        }
    }

    private void cargarDatosDeContactoEnSentencia(Contacto co, PreparedStatement ps) throws SQLException {
        ps.setString(1, co.getNombre());
        ps.setString(2, co.getApellido());
        ps.setString(3, co.getMail());
        ps.setString(4, co.getTelefono());
    }

    private Contacto generarContacto(ResultSet rs) throws SQLException {
        int id = rs.getInt(1);
        String nom = rs.getString(2);
        String ape = rs.getString(3);
        String mail = rs.getString(4);
        String tel = rs.getString(5);
        return new Contacto(id, nom, ape, mail, tel);
    }
}
